"""
Constituency Tree Generation Example
This script demonstrates how to parse sentences and extract constituent/phrase structures.
We'll use two approaches:
1. NLTK with a simple grammar (for learning)
2. Berkeley Neural Parser (benepar) for real-world parsing
"""

import nltk
from nltk import Tree
# TreeView requires Tkinter GUI - we'll use text output instead

# Approach 1: Simple NLTK parsing with predefined grammar
def simple_constituency_parse():
    """
    Demonstrate basic constituency parsing with a simple CFG grammar.
    This is educational - real systems use trained models.
    """
    print("\n" + "="*80)
    print("APPROACH 1: Simple Grammar-Based Parsing (Educational)")
    print("="*80)
    
    # Define a simple Context-Free Grammar
    grammar = nltk.CFG.fromstring("""
        S -> NP VP
        NP -> Det N | Det N PP | N
        VP -> V Adj | V Adj CC NP VP
        PP -> P NP
        Det -> 'The' | 'the'
        N -> 'price' | 'service' | 'environment' | 'quality' | 'food'
        V -> 'is' | 'was'
        Adj -> 'reasonable' | 'poor' | 'delicious' | 'terrible'
        CC -> 'although' | 'but' | 'and'
        P -> 'in' | 'on'
    """)
    
    # Create parser
    parser = nltk.ChartParser(grammar)
    
    # Simple sentence that fits our grammar
    sentence = "The price is reasonable".split()
    
    print(f"\nSentence: {' '.join(sentence)}")
    print("\nConstituency Tree:")
    
    for tree in parser.parse(sentence):
        print(tree)
        tree.pretty_print()
        return tree

# Approach 2: Using Berkeley Neural Parser (more realistic)
def neural_constituency_parse():
    """
    Use Berkeley Neural Parser for real-world constituency parsing.
    This is what research papers typically use.
    """
    print("\n" + "="*80)
    print("APPROACH 2: Neural Constituency Parser (Real-world)")
    print("="*80)
    
    try:
        import spacy
        
        try:
            nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("\nspaCy model not found. Please install:")
            print("  python -m spacy download en_core_web_sm")
            return None
        
        try:
            import benepar
            # Try to add benepar to the pipeline
            if "benepar" not in nlp.pipe_names:
                nlp.add_pipe("benepar", config={"model": "benepar_en3"})
        except ImportError:
            print("\nbenepar not installed. Install with:")
            print("  pip install benepar")
            print("  python -c 'import benepar; benepar.download(\"benepar_en3\")'")
            return None
        except Exception as e:
            print(f"\nError loading benepar model: {e}")
            print("Try downloading the model:")
            print("  python -c 'import benepar; benepar.download(\"benepar_en3\")'")
            return None
        
        # Example sentences
        examples = [
            "The price is reasonable although the service and the environment are poor.",
            "The food was delicious but the service was terrible.",
            "I love the camera quality."
        ]
        
        for sentence in examples:
            doc = nlp(sentence)
            
            print(f"\nSentence: {sentence}")
            print("\nConstituency Tree:")
            
            for sent in doc.sents:
                print(sent._.parse_string)
                print("\nTree Structure:")
                tree = Tree.fromstring(sent._.parse_string)
                tree.pretty_print()
                
                # Extract phrase information
                print("\nPhrase Analysis:")
                analyze_phrases(tree)
            
            print("\n" + "-"*80)
        
        return doc
        
    except ImportError as e:
        print(f"\nMissing required package: {e}")
        print("\nNote: Install required packages with:")
        print("  pip install spacy benepar")
        print("  python -m spacy download en_core_web_sm")
        print("  python -c 'import benepar; benepar.download(\"benepar_en3\")'")
        return None

def analyze_phrases(tree, level=0):
    """
    Recursively analyze and print phrase structures from constituency tree.
    """
    if isinstance(tree, Tree):
        # Get phrase type and content
        phrase_type = tree.label()
        phrase_content = ' '.join(tree.leaves())
        
        indent = "  " * level
        print(f"{indent}{phrase_type}: '{phrase_content}'")
        
        # Recursively process subtrees
        for subtree in tree:
            if isinstance(subtree, Tree):
                analyze_phrases(subtree, level + 1)

def extract_noun_phrases(tree):
    """
    Extract all noun phrases from the constituency tree.
    This is useful for ABSA to identify potential aspects.
    """
    noun_phrases = []
    
    if isinstance(tree, Tree):
        if tree.label() == 'NP':
            noun_phrases.append(' '.join(tree.leaves()))
        
        for subtree in tree:
            if isinstance(subtree, Tree):
                noun_phrases.extend(extract_noun_phrases(subtree))
    
    return noun_phrases

def compare_with_dependency():
    """
    Show how constituency and dependency trees provide different information.
    """
    print("\n" + "="*80)
    print("COMPARISON: Constituency vs Dependency Trees")
    print("="*80)
    
    sentence = "The price is reasonable"
    
    print(f"\nSentence: {sentence}\n")
    
    print("Constituency Tree Focus:")
    print("  - Phrase structure: (NP: The price) (VP: is reasonable)")
    print("  - Hierarchical grouping of words into phrases")
    print("  - Shows 'what phrases exist'\n")
    
    print("Dependency Tree Focus:")
    print("  - Word relationships: price ← (nsubj) ← is → (acomp) → reasonable")
    print("  - Direct grammatical connections between words")
    print("  - Shows 'how words relate to each other'\n")
    
    print("For ABSA:")
    print("  - Dependency tree: Links 'price' directly to 'reasonable'")
    print("  - Constituency tree: Groups 'The price' as one phrase unit")
    print("  - Both perspectives help understand sentiment!\n")

if __name__ == "__main__":
    print("CONSTITUENCY TREE ANALYSIS")
    
    # Run simple example first
    simple_tree = simple_constituency_parse()
    
    # Try neural parser
    neural_constituency_parse()
    
    # Show comparison
    compare_with_dependency()
    
    print("\n" + "="*80)
    print("To install required packages:")
    print("  pip install spacy nltk benepar")
    print("  python -m spacy download en_core_web_sm")
    print("  python -c 'import benepar; benepar.download(\"benepar_en3\")'")
    print("="*80)