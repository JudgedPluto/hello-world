"""
Dependency Tree Generation Example using spaCy
This script demonstrates how to parse sentences and extract dependency relationships.
"""

import spacy
from spacy import displacy

# Load English model (you need to install it first: python -m spacy download en_core_web_sm)
nlp = spacy.load("en_core_web_sm")

def parse_dependency_tree(sentence):
    """
    Parse a sentence and extract dependency relationships.
    
    Args:
        sentence: Input sentence string
    
    Returns:
        doc: spaCy Doc object with dependency information
    """
    doc = nlp(sentence)
    return doc

def print_dependency_info(doc):
    """
    Print detailed dependency information for each token.
    """
    print("\n" + "="*80)
    print(f"Sentence: {doc.text}")
    print("="*80)
    print(f"{'Token':<15} {'Dependency':<12} {'Head':<15} {'Children'}")
    print("-"*80)
    
    for token in doc:
        children = [child.text for child in token.children]
        print(f"{token.text:<15} {token.dep_:<12} {token.head.text:<15} {', '.join(children)}")
    print("="*80 + "\n")

def create_adjacency_matrix(doc):
    """
    Create an adjacency matrix from the dependency tree.
    This is how the dependency tree is typically represented for GCN/GAT.
    
    Returns:
        A dictionary showing connections between words
    """
    n = len(doc)
    tokens = [token.text for token in doc]
    
    print("\nAdjacency Matrix Representation:")
    print(f"Tokens: {tokens}\n")
    
    # Create adjacency information
    adjacency = {}
    for i, token in enumerate(doc):
        adjacency[i] = {
            'token': token.text,
            'connected_to': []
        }
        
        # Add connection to head (parent)
        if token.head != token:  # Not root
            head_idx = [t for t in doc].index(token.head)
            adjacency[i]['connected_to'].append({
                'index': head_idx,
                'token': token.head.text,
                'relation': token.dep_
            })
        
        # Add connections to children
        for child in token.children:
            child_idx = [t for t in doc].index(child)
            adjacency[i]['connected_to'].append({
                'index': child_idx,
                'token': child.text,
                'relation': child.dep_
            })
    
    # Print adjacency information
    for idx, info in adjacency.items():
        connections = [f"{c['token']}({c['relation']})" for c in info['connected_to']]
        print(f"Node {idx} [{info['token']}]: {', '.join(connections) if connections else 'No connections'}")
    
    return adjacency

def visualize_dependency_tree(doc, output_file="dependency_tree.svg"):
    """
    Create a visual representation of the dependency tree.
    """
    svg = displacy.render(doc, style="dep", jupyter=False)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"\nVisualization saved to {output_file}")

# Example sentences (including the ABSA example from the paper)
examples = [
    "The price is reasonable although the service and the environment are poor.",
    "The food was delicious but the service was terrible.",
    "I love the camera quality."
]

if __name__ == "__main__":
    print("DEPENDENCY TREE ANALYSIS")
    print("=" * 80)
    
    for sentence in examples:
        doc = parse_dependency_tree(sentence)
        print_dependency_info(doc)
        adjacency = create_adjacency_matrix(doc)
        
        # Visualize first example
        if sentence == examples[0]:
            visualize_dependency_tree(doc, "dependency_tree_visualization.svg")
        
        print("\n" + "="*80 + "\n")